Ares V.0.0.1 
Check out the documentation at: https://github.com/astruyk/Ares/wiki

Changelists

V.0.0.1
	* Initial alpha release.