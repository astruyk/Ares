Current Version: V.0.1.0
Check out the documentation at: https://github.com/astruyk/Ares/wiki

Changelists

V.0.1.1
	* Fixed backgrounds on some UI elements being transparent
	* Reinforcements - Expanded deletion radius of 'Delete LZ/RP' module to 15m (from 5m)
	* Reinforcements - Helicopters no longer wait after unloading troops.
	* Reinforcements - Units don't wait as long before deleting themselves.

V.0.1.0 - BETA!
	* Add 'Reinforcements' module. 
	* Fix backpacks not being removed when clearing inventory for Arsenal
	* Fix pasting not working in MP (Affected Save/Load as well as Arsenal functions)
	* Added the ability to paste saved objects into their original objects (instead of just relative to the cursor)
	* Fixed issue where zeus teleporting himself would show the 'You are being teleported' message (was redundant)
	* Added module to 'Save/Load' for Zeus to add all objects in the map to curator
	* Added ability to teleport a group

V.0.0.2
	* Added Arsenal functions

V.0.0.1
	* Initial alpha release.