name = "Ares 0.1.1";
picture = "ares_logo.paa";
actionName = "Website";
action = "https://github.com/astruyk/Ares";
tooltip = "Ares 0.1.1";
overview = "Ares augments the existing Zeus functionality, expanding the toolset and making it possible to create more compelling missions on the fly.";
author = "Anton Struyk";