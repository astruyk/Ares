Ares V.0.0.2
Check out the documentation at: https://github.com/astruyk/Ares/wiki

Changelists

V.0.0.1
	* Added Arsenal functions

V.0.0.1
	* Initial alpha release.